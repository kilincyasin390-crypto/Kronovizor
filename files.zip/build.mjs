// Kronovizör statik site oluşturucu: Türkçe Vikipedi'den 366 gün sayfası + 12 ay sayfası + site haritası üretir.
import {mkdir,writeFile,readFile,readdir,copyFile} from 'node:fs/promises';

const BASE=(process.env.SITE_URL||process.env.URL||'').replace(/\/+$/,'');
const UA=`KronovizorBuilder/1.0 (${BASE||'https://kronovizor.example'}; statik site olusturucu)`;
const M=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
const LOC=["Ocak'ta","Şubat'ta","Mart'ta","Nisan'da","Mayıs'ta","Haziran'da","Temmuz'da","Ağustos'ta","Eylül'de","Ekim'de","Kasım'da","Aralık'ta"];
const SL=['ocak','subat','mart','nisan','mayis','haziran','temmuz','agustos','eylul','ekim','kasim','aralik'];
const ND=[31,29,31,30,31,30,31,31,30,31,30,31];
const CUM=[0,31,60,91,121,152,182,213,244,274,305,335]; // artık yıl takvimine göre
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

async function wiki(title){
  const u='https://tr.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&redirects=1&format=json&titles='+encodeURIComponent(title);
  for(let i=0;;i++){
    try{
      const r=await fetch(u,{headers:{'User-Agent':UA,'Api-User-Agent':UA}});
      if(!r.ok)throw new Error('HTTP '+r.status);
      return Object.values((await r.json()).query.pages)[0].extract||'';
    }catch(e){if(i>=3)throw new Error(title+': '+e.message);await sleep(1500*(i+1))}
  }
}
function secs(t){const o={};let k='';for(const l of t.split('\n')){const h=l.match(/^==\s*([^=].*?)\s*==\s*$/);if(h){k=h[1];o[k]=[]}else if(k&&l.trim())o[k].push(l.trim())}return o}
function items(a){
  const o=[];let y=null;
  for(const l of a){
    if(l[0]=='=')continue;
    let m=l.match(/^((?:MÖ\s*)?\d{1,4})\s*[-–—]\s*(.+)$/);
    if(m){o.push([m[1],m[2]]);y=null}
    else if(m=l.match(/^((?:MÖ\s*)?\d{3,4})$/))y=m[1];
    else if(y)o.push([y,l.replace(/^[-–•*]\s*/,'')]);
  }
  return o;
}
async function pool(list,n,fn){let i=0;await Promise.all(Array.from({length:n},async()=>{while(i<list.length)await fn(list[i++])}))}

// 1) Veriyi topla
const days=[];
M.forEach((mn,mi)=>{for(let d=1;d<=ND[mi];d++)days.push({m:mi,d,name:`${d} ${mn}`,slug:`${d}-${SL[mi]}`})});
let sample='';
await pool(days,4,async x=>{
  const t=await wiki(x.name),s=secs(t);
  x.ev=items(s['Olaylar']||[]);x.bi=items(s['Doğumlar']||[]).slice(0,60);x.de=items(s['Ölümler']||[]).slice(0,60);
  x.hol=(s['Tatiller ve özel günler']||[]).filter(l=>l[0]!='=');
  if(!sample&&!x.ev.length)sample=t.slice(0,600);
});
const live=days.filter(x=>x.ev.length||x.bi.length||x.de.length);
console.log(`Veri alındı: ${live.length}/366 gün içerik içeriyor.`);
if(live.length<300){console.error('HATA: Beklenenden az gün ayrıştırıldı. Vikipedi sayfa düzeni değişmiş olabilir.\nÖrnek metin:\n'+sample);process.exit(1)}

// 2) Ortak parçalar
const CSS=`:root{--bg:#f6f4ef;--fg:#0c0c0c;--mut:#6b6a66;--red:#e0392f;--mono:'JetBrains Mono',ui-monospace,monospace;--hd:Oswald,'Arial Narrow',Impact,sans-serif}
@media(prefers-color-scheme:dark){:root{--bg:#121211;--fg:#f2efe8;--mut:#9a978f;--red:#ff6258}}
*{box-sizing:border-box;margin:0}body{background:var(--bg);color:var(--fg);font:400 16px/1.55 Inter,system-ui,sans-serif}a{color:inherit}
header{display:flex;flex-wrap:wrap;gap:6px 20px;align-items:baseline;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--fg)}
.brand{font:700 28px var(--hd);text-transform:uppercase;text-decoration:none}
nav a{font:500 12px var(--mono);text-transform:uppercase;margin-right:12px;text-decoration:none;display:inline-block;padding:4px 0}
main{max-width:860px;margin:auto;padding:22px 18px}
h1{font:700 clamp(32px,8vw,60px)/1.05 var(--hd);text-transform:uppercase;margin:8px 0 14px}
h2{font:700 24px var(--hd);text-transform:uppercase;margin:30px 0 8px}
ul{padding:0}li{list-style:none;padding:8px 0;border-bottom:1px solid var(--mut)}li b{font:500 14px var(--mono);color:var(--red)}
.crumb{font:400 12px var(--mono);text-transform:uppercase;color:var(--mut)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px}
.grid a{border:1px solid var(--fg);padding:10px;text-align:center;text-decoration:none}
.pn{display:flex;justify-content:space-between;gap:10px;margin:28px 0;font:500 13px var(--mono);text-transform:uppercase}
.cta{display:inline-block;background:var(--fg);color:var(--bg);padding:12px 16px;font:500 13px var(--mono);text-transform:uppercase;text-decoration:none;margin:14px 0}
.src{font-size:13px;color:var(--mut);margin-top:30px}
footer{padding:16px 18px;border-top:1px solid var(--fg);font:400 12px var(--mono);color:var(--mut)}`;
const FONTS='<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&family=Inter:wght@400;500&family=JetBrains+Mono:wght@400;500&display=swap">';
const HEAD=`<header><a class="brand" href="/">Kronovizör</a><nav aria-label="Aylar">${M.map((n,i)=>`<a href="/${SL[i]}/">${n}</a>`).join('')}</nav></header>`;
const LIC='<a href="https://creativecommons.org/licenses/by-sa/4.0/deed.tr" rel="license noopener">CC BY-SA 4.0</a>';
const FOOT=`<footer>© ${new Date().getFullYear()} Kronovizör · Bilgiler Türkçe Vikipedi'den derlenmiştir (${LIC}). Genel bilgilendirme amaçlıdır; doğruluğu garanti edilmez.</footer>`;
function page({title,desc,path,body,crumbs}){
  const url=BASE?BASE+path:'';
  const ld=crumbs?`<script type="application/ld+json">${JSON.stringify({'@context':'https://schema.org','@type':'BreadcrumbList',itemListElement:crumbs.map((c,i)=>({'@type':'ListItem',position:i+1,name:c[0],...(BASE?{item:BASE+c[1]}:{})}))})}</script>`:'';
  return `<!DOCTYPE html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
${url?`<link rel="canonical" href="${url}">\n<meta property="og:url" content="${url}">`:''}
<meta property="og:type" content="website"><meta property="og:locale" content="tr_TR"><meta property="og:site_name" content="Kronovizör">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
<meta name="theme-color" content="#f6f4ef">
${FONTS}<link rel="stylesheet" href="/s.css">
${ld}</head><body>${HEAD}<main>${body}</main>${FOOT}</body></html>`;
}
const li=a=>a.map(([y,t])=>`<li><b>${esc(y)}</b> — ${esc(t)}</li>`).join('');
const sec=(h,a)=>a.length?`<h2>${h}</h2><ul>${a}</ul>`:'';
const cut=(s,n)=>s.length>n?s.slice(0,n-1).replace(/\s+\S*$/,'')+'…':s;

// 3) Gün sayfaları
const out=async(p,c)=>{await mkdir('dist/'+p,{recursive:true});await writeFile(`dist/${p?p+'/':''}index.html`,c)};
await mkdir('dist',{recursive:true});await writeFile('dist/s.css',CSS);
live.forEach((x,i)=>{x.i=i});
for(const x of live){
  const doy=CUM[x.m]+x.d,mm=x.m;
  const where=mm==1&&x.d==29?'yalnızca artık yıllarda bulunur ve yılın 60. günüdür':mm>=2?`yılın ${doy-1}. (artık yıllarda ${doy}.) günüdür`:`yılın ${doy}. günüdür`;
  const first=x.ev.filter(e=>/^\d/.test(e[0])).slice(0,2).map(e=>`${e[0]}: ${e[1]}`).join(' · ');
  const prev=live[(x.i+live.length-1)%live.length],next=live[(x.i+1)%live.length];
  const monthDays=live.filter(z=>z.m==mm);
  const body=`<p class="crumb"><a href="/">Kronovizör</a> › <a href="/${SL[mm]}/">${M[mm]}</a> › ${x.name}</p>
<h1>${LOC[mm].replace(/^/,x.d+' ')} tarihte neler oldu?</h1>
<p>${x.name}, Miladi takvime göre ${where}. Aşağıda bu tarihte dünyada ve Türkiye'de yaşanan olayları, doğumları ve ölümleri bulabilirsin.</p>
<a class="cta" href="/">Yıl seçerek keşfet</a>
${sec('Olaylar',li(x.ev))}${sec('Doğumlar',li(x.bi))}${sec('Ölümler',li(x.de))}${sec('Bu günün özel günleri',x.hol.map(h=>`<li>${esc(h)}</li>`).join(''))}
<div class="pn"><a href="/${prev.slug}/">← ${prev.name}</a><a href="/${next.slug}/">${next.name} →</a></div>
<h2>${M[mm]} ayının diğer günleri</h2><div class="grid">${monthDays.map(z=>`<a href="/${z.slug}/">${z.d}</a>`).join('')}</div>
<p class="src">Bu sayfadaki bilgiler Türkçe Vikipedi'nin <a href="https://tr.wikipedia.org/wiki/${encodeURI(x.d+'_'+M[mm])}" rel="noopener">“${x.name}”</a> maddesinden (<a href="https://tr.wikipedia.org/w/index.php?title=${encodeURIComponent(x.d+'_'+M[mm])}&action=history" rel="noopener">yazarlar ve sürüm geçmişi</a>) derlenmiş, kısaltılmış ve yeniden düzenlenmiştir. İçerik Vikipedi katkıcılarına aittir; ${LIC} lisansı altında paylaşılır.</p>`;
  await out(x.slug,page({title:`${LOC[mm].replace(/^/,x.d+' ')} Tarihte Neler Oldu? | Kronovizör`,desc:cut(`${x.name} tarihte bugün. ${first}`,155),path:`/${x.slug}/`,body,crumbs:[['Kronovizör','/'],[M[mm],`/${SL[mm]}/`],[x.name,`/${x.slug}/`]]}));
}

// 4) Ay sayfaları
for(let mm=0;mm<12;mm++){
  const md=live.filter(z=>z.m==mm);
  const rows=md.map(z=>{const e=z.ev.find(e=>/^\d/.test(e[0]))||z.ev[0]||['',''];return `<li><b><a href="/${z.slug}/">${z.name}</a></b> ${e[0]?'· '+esc(e[0])+' — '+esc(cut(e[1],140)):''}</li>`}).join('');
  const body=`<p class="crumb"><a href="/">Kronovizör</a> › ${M[mm]}</p>
<h1>${M[mm]} ayında tarihte neler oldu?</h1>
<p>${M[mm]} ayının her günü için dünyada ve Türkiye'de yaşanan olaylara göz at.</p>
<div class="grid">${md.map(z=>`<a href="/${z.slug}/">${z.d}</a>`).join('')}</div>
<h2>Günlere göre öne çıkanlar</h2><ul>${rows}</ul>
<p class="src">Bilgiler Türkçe Vikipedi katkıcılarına aittir; kısaltılmış ve yeniden düzenlenmiş olarak ${LIC} lisansı altında paylaşılır.</p>`;
  await out(SL[mm],page({title:`${M[mm]} Ayında Tarihte Neler Oldu? | Kronovizör`,desc:`${M[mm]} ayının her günü için tarihte bugün: dünyada ve Türkiye'de yaşanan olaylar, doğumlar ve ölümler.`,path:`/${SL[mm]}/`,body,crumbs:[['Kronovizör','/'],[M[mm],`/${SL[mm]}/`]]}));
}

// 5) Ana sayfa (etkileşimli uygulama) + 404 + robots + sitemap
let app=await readFile('app.html','utf8');
app=app.replace('<footer>',`<nav aria-label="Aylara göre tarihte bugün" style="padding:14px 18px;font:12px/2 monospace;text-transform:uppercase">${M.map((n,i)=>`<a href="/${SL[i]}/">${n}</a>`).join(' · ')}</nav>\n<footer>`);
if(BASE)app=app.replace('</head>',`<link rel="canonical" href="${BASE}/">\n<meta property="og:url" content="${BASE}/">\n</head>`);
await writeFile('dist/index.html',app);
// Google Search Console doğrulama dosyalarını (google*.html) siteye kopyala
for(const f of await readdir('.'))if(/^google.*\.html$/.test(f))await copyFile(f,'dist/'+f);
await writeFile('dist/404.html',page({title:'Sayfa bulunamadı | Kronovizör',desc:'Aradığın sayfa bulunamadı.',path:'/404.html',body:`<h1>Sayfa bulunamadı</h1><p>Aradığın sayfa yok. <a href="/">Ana sayfaya dön</a> ya da bir ay seç.</p>`}));
if(BASE){
  const today=new Date().toISOString().slice(0,10),urls=['/',...SL.map(s=>`/${s}/`),...live.map(x=>`/${x.slug}/`)];
  await writeFile('dist/sitemap.xml',`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u=>`<url><loc>${BASE}${u}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>\n`);
  await writeFile('dist/robots.txt',`User-agent: *\nAllow: /\nSitemap: ${BASE}/sitemap.xml\n`);
  console.log(`Site haritası: ${urls.length} adres (${BASE})`);
}else{
  await writeFile('dist/robots.txt','User-agent: *\nAllow: /\n');
  console.warn('UYARI: SITE_URL/URL tanımlı değil; site haritası ve canonical etiketleri üretilmedi.');
}
console.log(`Tamam: ${live.length} gün + 12 ay sayfası üretildi.`);
